# ZanichelliExpenseManager
This project is a programming case-study in C++ for the follow italian school textbook:
G. Meini, F. Formichi, "Tecnologie e progettazione di sistemi informatici e di telecomunicazioni", terza ed., Zanichelli, 2022
