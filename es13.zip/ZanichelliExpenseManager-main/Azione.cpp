
#include "Azione.h"

Azione::~Azione(void) {}
